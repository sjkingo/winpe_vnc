You must delete the \setup.exe file, or startnet.cmd won't get run! A copy exists in \deploy that will
be copied back once the custom initialisation is finished.

startnet.cmd goes in \Windows\system32

Delete this file when finished.